import React, { Component } from 'react';

class HomeComponent extends Component {
    render() {
        return (
            <div>
                <h1 className="text-info">Home Component</h1>
                <h4 className="text-warning">This is a Simple, React Routing Application</h4>
            </div>
        );
    }
}

export default HomeComponent;   
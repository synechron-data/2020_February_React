const url = "https://jsonplaceholder.typicode.com/posts";

const postAPIClient = {
    getAllPosts: function () {
        return new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    setTimeout(() => {
                        resolve(data);
                    }, 5000);
                }).catch((err) => {
                    // Logging of Actual Error
                    reject("Parsing Error");
                });
            }).catch((err) => {
                // Logging of Actual Error
                reject("Communication Error");
            });
        });
    }
}

export default postAPIClient;
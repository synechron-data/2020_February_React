/* eslint-disable */
import React from 'react';
import DataFlowAssignment from '../1_Assignments/DataFlowAssignment';
import CalculatorAssignment from '../1_Assignments/CalculatorAssignment';
import PropTypesRoot from '../2_PropTypes/PropTypesDemo';
import ErrorHandler from '../common/ErrorHandler';
import ListRoot from '../3_List/ListComponent';
import FormAssignment from '../1_Assignments/FormAssignment';
import AjaxComponent from '../4_Ajax/AjaxComponent';
import ContextAPIDemoComponent from '../5_Context/ContextAPIDemo';
import StateHook from '../6_Hooks/StateHook';

const RootComponent = () => {
    return (
        <div className="container">
            <ErrorHandler>
                {/* <DataFlowAssignment /> */}
                {/* <CalculatorAssignment /> */}
                {/* <PropTypesRoot /> */}
                {/* <ListRoot /> */}
                {/* <FormAssignment /> */}
                {/* <AjaxComponent /> */}
                {/* <ContextAPIDemoComponent /> */}
                <StateHook />
            </ErrorHandler>
        </div>
    );
};

export default RootComponent;
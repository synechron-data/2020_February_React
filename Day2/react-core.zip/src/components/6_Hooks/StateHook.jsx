import React, { Component, useState } from 'react';

class WithoutHooks extends Component {
    constructor(props) {
        super(props);
        this.state = { count: 0 };
    }

    handleClick() {
        this.setState({ count: this.state.count + 1 });
    }

    render() {
        return (
            <div>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click</button>
            </div>
        );
    }
}

const WithHooks = () => {
    const [count, setCount] = useState(0);
    const [message, setMessage] = useState("Hello");
    console.log(count);
    console.log(setCount);

    return (
        <div>
            <h2 className="text-info">Count: {count}</h2>
            <button className="btn btn-primary" onClick={() => setCount(count + 1)}>Click</button>
        </div>
    );
};

class StateHook extends Component {
    render() {
        return (
            <div>
                <WithoutHooks />
                <WithHooks />
            </div>
        );
    }
}


export default StateHook;
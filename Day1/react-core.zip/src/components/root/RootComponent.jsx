// import React, { Component } from 'react';

// class RootComponent extends Component {
//     render() {
//         return (
//             <div>
//                 <h1 className={"card"}>Hello World</h1>
//                 <h1 className={"card"}>Hello World</h1>
//             </div>
//         );
//     }
// }

// export default RootComponent;

// ---------------------------------------------
// import React from 'react';

// function RootComponent() {
//     return (
//         <div>
//             <h1 className={"card"}>Hello World</h1>
//             <h1 className={"card"}>Hello World</h1>
//         </div>
//     );
// };


// const RootComponent = function () {
//     return (
//         <div>
//             <h1 className={"card"}>Hello World</h1>
//             <h1 className={"card"}>Hello World</h1>
//         </div>
//     );
// };

// const RootComponent = () => {
//     return (
//         <div>
//             <h1 className={"card"}>Hello World</h1>
//             <h1 className={"card"}>Hello World</h1>
//         </div>
//     );
// };

// const RootComponent = () => (
//     <div className="container">
//         <h1 className={"card"}>Hello World</h1>
//         <h1 className={"card"}>Hello World</h1>
//     </div>
// );

// export default RootComponent;

// ---------------------------------------------

import React from 'react';

// import ComponentOne from '../1_multi-components/ComponentOne';
// import ComponentTwo from '../1_multi-components/ComponentTwo';

// import ComponentOne from '../2_components-with-css/ComponentOne';
// import ComponentTwo from '../2_components-with-css/ComponentTwo';

// import ComponentOne from '../3_external-css/comp-one/ComponentOne';
// import ComponentTwo from '../3_external-css/comp-two/ComponentTwo';

// import ComponentOne from '../4_css-modules/comp-one/ComponentOne';
// import ComponentTwo from '../4_css-modules/comp-two/ComponentTwo';

import ComponentWithState from '../5_comp-state/ComponentWithState';
import ComponentWithProps from '../6_comp-props/ComponentWithProps';
import ComponentWithBehavior from '../7_comp-behavior/ComponentWithBehavior';
import ClassVsFunctionalComponents from '../8_ClassVsFunc/ClassVsFunctionalComponents';
import ReactEventComponent from '../9_EventComponent/ReactEventComponent';
import CounterAssignment from '../10_Assignment/CounterAssignment';
import DataFlowAssignment from '../10_Assignment/DataFlowAssignment';
import ControllerVsUnControlledComponent from '../11_ControllerVsUnControlled/ControllerVsUnControlledComponent';

const RootComponent = () => {
    return (
        <div className="container">
            {/* <ComponentOne />
            <ComponentTwo /> */}

            {/* <ComponentWithState /> */}
            {/* <ComponentWithProps name={"Synechron"} city={"Pune"}
                address={{ st: "MH", con: "IN" }}
                display={function () { alert("clicked....") }} /> */}
            {/* <ComponentWithBehavior /> */}
            {/* <ClassVsFunctionalComponents /> */}
            {/* <ReactEventComponent /> */}
            {/* <CounterAssignment /> */}
            {/* <DataFlowAssignment /> */}
            <ControllerVsUnControlledComponent />
        </div>
    );
};

export default RootComponent;
import React, { Component } from 'react';

class ComponentWithProps extends Component {
    constructor(props) {
        super(props);
        // this.state = { id: 1 };
        // this.props = { name: "Synechron" };
        // this.props.name = "Changed";         //Props are readonly

        // this.state = this.props;
        // this.state.name = "Changed";         

        // Shallow Copy
        // this.state = Object.assign({}, this.props);
        // this.state = {...this.props};   // ES2018
        
        // Deep Copy
        this.state = JSON.parse(JSON.stringify(this.props));
        this.state.name = "Changed";  
        this.state.address.st = "GA";

        // Deep Copy With Functions (Methods) - immutability-helper

        console.log("Ctor, State: ", this.state);
        console.log("Ctor, Props: ", this.props);
    }

    render() {
        console.log("Render, State: ", this.state);
        console.log("Render, Props: ", this.props);
        return (
            <div>
                <h2 className="text-info">Component With Props</h2>
            </div>
        );
    }
}

export default ComponentWithProps;
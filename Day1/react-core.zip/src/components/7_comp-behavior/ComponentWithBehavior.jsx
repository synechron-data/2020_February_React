import React, { Component } from 'react';

class ComponentWithBehavior extends Component {
    constructor(props) {
        super(props);
        this.state = { id: 1, count: 0 };
    }

    handleClick() {
        // this.state.count += 1;
        // console.log(this.state); 

        this.setState({ count: this.state.count + 1 }, () => {
            console.log(this.state);
        });
    }

    render() {
        return (
            <div>
                <h2 className="text-info">Id: {this.state.id}</h2>
                <h2 className="text-info">Count: {this.state.count}</h2>
                <button className="btn btn-primary" onClick={this.handleClick.bind(this)}>Click</button>
            </div>
        );
    }
}

export default ComponentWithBehavior;
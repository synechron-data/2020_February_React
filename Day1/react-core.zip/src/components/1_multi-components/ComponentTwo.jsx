import React from 'react';

const ComponentTwo = () => (
    <h1 className="text-warning">Hello from Component Two</h1>
);

export default ComponentTwo;
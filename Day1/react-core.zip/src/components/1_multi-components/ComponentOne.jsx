import React from 'react';

const ComponentOne = () => (
    <h1 className="text-danger">Hello from Component One</h1>
);

export default ComponentOne;
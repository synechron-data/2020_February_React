import React from 'react';

const card2 = {
    margin: '1em',
    paddingLeft: 0,
    border: '2px dashed yellow'
}

const ComponentTwo = () => (
    <h1 style={card2} className="text-warning">Hello from Component Two</h1>
);

export default ComponentTwo;
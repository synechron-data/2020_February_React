import React from 'react';

const card1 = {
    margin: '1em',
    paddingLeft: 0,
    border: '2px solid red'
}

const ComponentOne = () => (
    <h1 style={card1} className="text-danger">Hello from Component One</h1>
);

export default ComponentOne;
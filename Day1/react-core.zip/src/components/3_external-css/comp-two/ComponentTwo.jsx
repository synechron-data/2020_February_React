import React from 'react';

import './ComponentTwo.css';

const ComponentTwo = () => (
    <h1 className="card2 text-warning">Hello from Component Two</h1>
);

export default ComponentTwo;
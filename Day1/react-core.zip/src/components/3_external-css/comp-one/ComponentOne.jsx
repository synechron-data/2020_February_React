import React from 'react';

import './ComponentOne.css';

const ComponentOne = () => (
    <h1 className="card1 text-danger">Hello from Component One</h1>
);

export default ComponentOne;
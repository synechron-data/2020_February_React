import React from 'react';

import { card } from './ComponentOne.module.css';

const ComponentOne = () => (
    <h1 className={`text-danger ${card}`}>Hello from Component One</h1>
);

export default ComponentOne;
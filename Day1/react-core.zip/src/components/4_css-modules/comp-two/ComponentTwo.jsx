import React from 'react';

import styles from './ComponentTwo.module.css';

const ComponentTwo = () => (
    <h1 className={`text-warning ${styles.card}`}>Hello from Component Two</h1>
);

export default ComponentTwo;
// import React from 'react';
// import ReactDOM from 'react-dom';
// import './index.css';
// import RootComponent from './components/root/RootComponent';

// ReactDOM.render(<RootComponent />, document.getElementById('root'));

// ---------------------------- Using BS 4
// npm install --save bootstrap popper.js jquery
// npm install --save-dev node-sass

// import 'bootstrap/scss/bootstrap.scss';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import './index.css';
// import RootComponent from './components/root/RootComponent';


// ReactDOM.render(<RootComponent />, document.getElementById('root'));


// ---------------------------- Multi Components
// import 'bootstrap/scss/bootstrap.scss';

// import React from 'react';
// import ReactDOM from 'react-dom';
// import 'bootstrap';

// import './index.css';

// import ComponentOne from './components/multi-components/ComponentOne';
// import ComponentTwo from './components/multi-components/ComponentTwo';

// ReactDOM.render(<ComponentOne />, document.getElementById("root1"));
// ReactDOM.render(<ComponentTwo />, document.getElementById("root2"));

// ReactDOM.render(<React.Fragment>
//     <ComponentOne />
//     <ComponentTwo />
// </React.Fragment>, document.getElementById("root"));

// ReactDOM.render([<ComponentOne />, <ComponentTwo />], document.getElementById("root"));

// ReactDOM.render([<RootComponent />, document.getElementById("root"));

// ---------------------------- Nested Components
import 'bootstrap/scss/bootstrap.scss';

import React from 'react';
import ReactDOM from 'react-dom';
import 'bootstrap';

import './index.css';
import RootComponent from './components/root/RootComponent';

ReactDOM.render(<RootComponent />, document.getElementById("root"));